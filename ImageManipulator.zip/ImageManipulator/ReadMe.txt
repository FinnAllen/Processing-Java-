------------------------------------------
IMPORTANT
------------------------------------------
In order for the program to run, you must
add an image to the data folder to manipulate.
You must also input the dimensions of the
image (line 21) as well as the image name 
(line 27) into the code.
------------------------------------------